package com.example.md_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
