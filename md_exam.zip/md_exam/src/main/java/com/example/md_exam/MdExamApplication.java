package com.example.md_exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdExamApplication.class, args);
	}

}
