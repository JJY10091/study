package com.example.tut06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
